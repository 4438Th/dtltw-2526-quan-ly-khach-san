document.addEventListener("DOMContentLoaded", function () {
  console.log("App loaded");
});
