<?php
session_start();
require_once 'init.php';

use core\Router;

$app = new Router();
