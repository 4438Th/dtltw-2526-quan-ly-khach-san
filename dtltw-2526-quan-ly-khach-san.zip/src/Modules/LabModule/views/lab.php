<?php
include SHARE_PATH . '/view/includes/layout/head.php';
include SHARE_PATH . '/view/includes/component/header.php';
include SHARE_PATH . '/view/includes/component/labNavbar.php';
include SRC_PATH . '/Modules/LabModule/views/labView.php';
include SHARE_PATH . '/view/includes/layout/footer.php';
