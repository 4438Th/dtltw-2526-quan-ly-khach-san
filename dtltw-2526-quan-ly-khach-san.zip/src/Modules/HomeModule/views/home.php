<?php
include SHARE_PATH . '/view/includes/layout/head.php';
include SHARE_PATH . '/view/includes/component/header.php';
include SHARE_PATH . '/view/includes/component/homeNavbar.php';
include SRC_PATH . '/Modules/HomeModule/views/roomView.php';
include SHARE_PATH . '/view/includes/layout/footer.php';
