<?php
define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '12345678');
define('DB_NAME', 'thltw2526');
define('DB_CHARSET', 'utf8mb4');
define('DB_NAME_LAB08', 'bookstore');
