<?php
echo 'biến x định nghĩa ở file lab2_5a.php nên ở đây lỗi<br>';
$x += 10;
