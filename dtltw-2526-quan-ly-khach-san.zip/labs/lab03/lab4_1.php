<?php
$s = 0;
for ($i = 0; $i <= 100; $i++) {
    if ($i % 2 == 0)
        $s += $i;
}
echo $s;
