<h1>Trang: Example_01</h1>
<?php
phpinfo();
?>