<?php
echo 'Tạm ngừng 3 giây! <br>';
sleep(3);
phpinfo();
